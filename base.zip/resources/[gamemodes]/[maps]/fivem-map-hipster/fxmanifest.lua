resource_type 'map' { gameTypes = { ['basic-gamemode'] = true } }

map 'map.lua'

fx_version 'adamant'
game 'gta5'