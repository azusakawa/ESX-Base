fx_version 'adamant'
game 'common'

dependencies {
	'yarn'
}

server_script 'sm_server.js'