Locales['en'] = {
  ['show_registration'] = 'show Registration Menu',
  ['show_active_character'] = 'show Active Character',
  ['delete_character'] = 'delete Your Character And Create A New One',
  ['deleted_character'] = 'your character has been deleted.',
  ['not_registered'] = 'you do not have a character reistered.',
  ['active_character'] = '~b~active Character:~s~ %s %s',
  ['already_registered'] = 'you already have a character registered.',
  ['failed_identity'] = 'failed to set your character, try again later or contact the server admin!',
  ['create_a_character'] = 'you have to create a character in order to play.'
}
